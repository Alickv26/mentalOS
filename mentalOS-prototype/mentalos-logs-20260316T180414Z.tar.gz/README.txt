mentalOS log bundle

Contents:
- logs/mentalOS.log(.1) if present
- config/config.toml if present
- config/shortcuts.toml if present

Review and redact secrets before sharing externally.
